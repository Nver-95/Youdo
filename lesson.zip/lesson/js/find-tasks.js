window.addEventListener('resize', () => {
    if (window.innerWidth >= 320) {
        console.log(window.innerWidth)
    }
})


let bi_capslock = document.querySelector('.bi-capslock')
window.addEventListener('scroll', () => {
    if (window.pageYOffset > 100) {
        bi_capslock.classList.add("active")
    } else {
        bi_capslock.classList.remove("active")
    }
})
if (bi_capslock) {
    bi_capslock.addEventListener('click', scrollToTop)
}

function scrollToTop() {
    window.scrollTo({top: 0, behavior: 'smooth'});
}


let tasks = document.querySelector(".tasks")
let info = document.querySelector(".viewed-tasks-info")
tasks.setAttribute("style","display:none");
let button = document.querySelector(".btn-vacancies")
button.addEventListener("click", (event) => {
    if (tasks.classList.toggle("d-none")) {
        tasks.setAttribute("style","display:block");
        info.setAttribute("style","display:none");
    }else {
        tasks.setAttribute("style","display:none");
    }
})


let content_maps = document.querySelectorAll('.btn-maps')
let find_maps = document.querySelector(".map-search")
find_maps.setAttribute("style","display:none")
let work_services_maps = document.querySelector(".work-services-maps")
work_services_maps.setAttribute("style","display:block")
if (content_maps) {
    content_maps.forEach((el, i) => {
        el.addEventListener('click', () => {
            work_services_maps.classList.toggle('d-none')
            find_maps.classList.toggle('d-block')
        })
    })
}


let map_icon = document.querySelectorAll('.map-icon')
let work_maps = document.querySelector('.work-services')
let list_work = document.querySelector(".list-of-works")
let list_icon = document.querySelector(".list-icon")
list_icon.setAttribute("style","display:none")
    if (map_icon) {
        map_icon.forEach((el, i) => {
            el.addEventListener('click', () => {
                work_maps.classList.toggle('d-block')
                list_work.classList.toggle('d-none')
                map_icon .classList.toggle('d-none')
                list_icon.classList.toggle('d-block')
            })
        })
    }


let filter_icon = document.querySelectorAll('.filter-icon')
let filter_address_content = document.querySelector('.filter-address-content')
let filter_search = document.querySelector(".filter-search")
let close_icon = document.querySelector(".close-icon")
    filter_icon.forEach((el, i) => {
        el.addEventListener('click', () => {
            filter_search.classList.toggle('d-none')
            filter_address_content.classList.toggle('d-block')
            close_icon.classList.toggle('d-block')
        })
    })



