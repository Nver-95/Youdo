// $('.toggle-all').on('click', function() {
//     $('#infinite_carousel .row').toggleClass('flex-nowrap');
//     $('#infinite_carousel .control').toggleClass('d-none');
//     $(this).html($('#infinite_carousel .row').hasClass('flex-nowrap') ? '<i class="fa fa-th" aria-hidden="true"></i> Show All' : '<i class="fa fa-chevron-right" aria-hidden="true"></i> Show Slider');
// });
//
// $('#infinite_carousel .fa-chevron-right').on('click', () => {
//     let $infinite_carousel_row = $('#infinite_carousel .row');
//     let $col = $infinite_carousel_row.find('.col-6:first');
//     $infinite_carousel_row.append($col[0].outerHTML);
//     $col.remove();
// });
//
// $('#infinite_carousel .fa-chevron-left').on('click', () => {
//     let $infinite_carousel_row = $('#infinite_carousel .row');
//     let $col = $infinite_carousel_row.find('.col-6:last');
//     $infinite_carousel_row.prepend($col[0].outerHTML);
//     $col.remove();
// });

let text = document.querySelector('.form-text-span');
text.onclick = function () {
    let input = document.querySelector('.form-control-input');
    input.value = text.innerHTML
}

// text.addEventListener('click', (event) => {
//     let input = document.querySelector('.form-control-input');
//     input.value = text.innerHTML
// })


document.addEventListener('click', (event) => {
    // event.target
    // console.log(event.target == document.querySelector('.form-text-span'))
    if (event.target == document.querySelector('.form-text-span')) {
        let input = document.querySelector('.form-control-input');
        input.value = text.innerHTML
    }
})

